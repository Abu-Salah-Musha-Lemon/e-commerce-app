import Entities.Booking;
import FileManager.BookingManager;
import GUI.BookingGUI;
public class Start{
    public static void main(String[] args){
        BookingGUI b = new BookingGUI();
		
    }
    


}