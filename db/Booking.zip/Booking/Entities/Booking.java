package Entities;
public class Booking {
    private int sl;
    private String name;
    private String busName;
    private String date;
	private String travelDate;
    private String ticketType;
    private String destination;
	
    public Booking (){}
    public Booking ( String  sl,String name, String busName, String date,String travelDate,String ticketType,String destination){
        this.sl = Integer.parseInt(sl);
        this.name = name;
        this.busName= busName;
        this.date = date;
		this.travelDate=travelDate;
		this.ticketType=ticketType;
		this.destination=destination;
    } 
    //setter
    public void setSl(int sl){this.sl = sl;}
    public void setName(String name){this.name = name;}
    public void setDate(String date){this.date = date ;}
    public void setBusName(String busName){this.busName = busName;}
	public void setTravelDate(String travelDate){this.travelDate = travelDate;}
	public void setTicketType(String ticketType){this.ticketType = ticketType;}
	public void setDestination(String destination){this.destination = destination;}
    //getter
    public int getSl(){return sl;}
    public String getName(){return name;}
    public String getBusName(){return busName;}
	public String getDate(){return date ;}
	public String getTravelDate(){return travelDate;}
	public String getTicketType(){return ticketType;}
	public String getDestination(){return destination;}

    public void show(){
        System.out.println("Sl: " + sl);
        System.out.println("Name: " + name);
        System.out.println("Bus Name  " + busName);
        System.out.println("Date : " + date );
		System.out.println("Travel Date : " + travelDate );
		System.out.println("Ticket Type : " + ticketType );
		System.out.println("Destination " + destination);
    }
    public String getFileWriteFormat(){
        return sl+";"+name+";"+busName+";"+date+";"+travelDate+";"+ticketType+";"+destination+";"+"\n";
    }
    public Object[] getTableRow(){
        return new Object[] {sl,name,busName,date,travelDate,ticketType,destination};
    }
}
