package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener; // interface to handle button click event
import java.awt.event.ActionEvent;
import Entities.Booking;
import FileManager.BookingManager;
import javax.swing.table.DefaultTableModel;

public class BookingGUI extends JFrame implements ActionListener {
    JTextField txtBookingID;
    JTextField txtPassengerName;
    JTextField txtBusName;
    JTextField txtDate;
    JTextField txtTravelDate;
    JTextField txtTicketType;
    JTextField txtDestination;
    JButton submit;
    JButton update;
    JButton delete;
    DefaultTableModel tmodel;
    private Booking[] bookings; // Declared at class level

    public BookingGUI() {
        setSize(1300, 300);
		setTitle("Booking Now");
        setLayout(new FlowLayout());

        add(new JLabel("Booking ID"));
        txtBookingID = new JTextField(4);
        add(txtBookingID);

        add(new JLabel("Passenger Name"));
        txtPassengerName = new JTextField(10);
        add(txtPassengerName);

        add(new JLabel("Bus Name"));
        txtBusName = new JTextField(8);
        add(txtBusName);

        add(new JLabel("Booking Date"));
        txtDate = new JTextField(4);
        add(txtDate);

        add(new JLabel("Travel Date"));
        txtTravelDate = new JTextField(4);
        add(txtTravelDate);

        add(new JLabel("Ticket Type"));
        txtTicketType = new JTextField(4);
        add(txtTicketType);

        add(new JLabel("Destination"));
        txtDestination = new JTextField(6);
        add(txtDestination);

        submit = new JButton("Book");
        add(submit);
        submit.addActionListener(this);

        update = new JButton("Update");
        add(update);
        update.addActionListener(this);

        delete = new JButton("Cancel");
        add(delete);
        delete.addActionListener(this);

        // Table setup
        tmodel = new DefaultTableModel();
        tmodel.addColumn("B.ID");
        tmodel.addColumn("P.Name");
        tmodel.addColumn("BusName");
        tmodel.addColumn("B.Date");
        tmodel.addColumn("TravelDate");
        tmodel.addColumn("Ticket Type");
        tmodel.addColumn("Destination");

        JTable table = new JTable(tmodel);
        JScrollPane jspTable = new JScrollPane(table);
        add(jspTable);

        loadData(); // Load data from file

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            registerClicked();
        } else if (e.getSource() == delete) {
            deleteClicked();
        } else if (e.getSource() == update) {
            updateClicked();
        }
    }

    private void loadData() {
        BookingManager sm = new BookingManager();
        bookings = sm.getAllBookings();  // Assign bookings to class-level array

        if (bookings != null) {
            for (Booking s : bookings) {
                tmodel.addRow(s.getTableRow());
            }
        }
    }

    public void registerClicked() {
        String sl = txtBookingID.getText();
        String name = txtPassengerName.getText();
        String busName = txtBusName.getText();
        String date = txtDate.getText();
        String travelDate = txtTravelDate.getText();
        String ticketType = txtTicketType.getText();
        String destination = txtDestination.getText();

        Object[] row = new Object[]{sl, name, busName, date, travelDate, ticketType, destination};
        tmodel.addRow(row);

        Booking s = new Booking(sl, name, busName, date, travelDate, ticketType, destination);
        BookingManager sm = new BookingManager();
        sm.writeBooking(s, true);

        JOptionPane.showMessageDialog(null, "Booked ");
    }

    public void deleteClicked() {
        String sl = txtBookingID.getText();
        BookingManager sm = new BookingManager();
        sm.deleteBooking(Integer.parseInt(sl));

        refreshTable();
        JOptionPane.showMessageDialog(null, "Booking Canceled");
    }

    public void updateClicked() {
        String sl = txtBookingID.getText();
        String name = txtPassengerName.getText();
        String busName = txtBusName.getText();
        String date = txtDate.getText();
        String travelDate = txtTravelDate.getText();
        String ticketType = txtTicketType.getText();
        String destination = txtDestination.getText();

        Booking s = new Booking(sl, name, busName, date, travelDate, ticketType, destination);
        BookingManager sm = new BookingManager();
        sm.updateBooking(s);

        refreshTable();
        JOptionPane.showMessageDialog(null, "Booking Updated");
    }

    public void refreshTable() {
        tmodel.getDataVector().removeAllElements(); // Clear table
        BookingManager sm = new BookingManager();
        bookings = sm.getAllBookings();  // Reload bookings

        if (bookings != null) {
            for (Booking s : bookings) {
                tmodel.addRow(s.getTableRow());
            }
        }
    }
}
