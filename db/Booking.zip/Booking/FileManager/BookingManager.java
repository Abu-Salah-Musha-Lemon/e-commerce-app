package FileManager;

import Entities.Booking;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;

public class BookingManager {
    String filePath;

    public BookingManager() {
        filePath = "DataFiles/data.txt";
    }

    public void writeBooking(Booking s, boolean append) {
        File f = new File(filePath);
        try {
            FileWriter writer = new FileWriter(f, append);
            writer.write(s.getFileWriteFormat());
            writer.flush();
            writer.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Booking[] getAllBookings() {
        File f = new File(filePath);
        Booking[] bookings = null;

        try {
            Scanner sc = new Scanner(f);
            int count = 0;

            // Count the number of lines
            while (sc.hasNextLine()) {
                sc.nextLine();
                count++;
            }
            sc.close();

            // Reopen the file to load bookings
            sc = new Scanner(f);
            bookings = new Booking[count];
            count = 0;

            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] data = line.split(";");
                Booking s = new Booking(data[0], data[1], data[2], data[3], data[4], data[5], data[6]);
                bookings[count] = s;
                count++;
            }
            sc.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return bookings;
    }

    public void deleteBooking(int sl) {
        Booking[] bookings = getAllBookings();  // Retrieve all bookings

        // Mark booking as null for deletion
        for (int i = 0; i < bookings.length; i++) {
            if (bookings[i] != null && bookings[i].getSl() == sl) {
                bookings[i] = null;
            }
        }

        // Write remaining bookings to file
        boolean isFirst = true;
        for (Booking booking : bookings) {
            if (booking != null) {
                writeBooking(booking, !isFirst);  // Append after first write
                isFirst = false;
            }
        }
    }

    public void updateBooking(Booking s) {
        Booking[] bookings = getAllBookings();  // Retrieve all bookings

        // Update booking if found
        for (int i = 0; i < bookings.length; i++) {
            if (bookings[i] != null && bookings[i].getSl() == s.getSl()) {
                bookings[i].setName(s.getName());
                bookings[i].setBusName(s.getBusName());
                bookings[i].setDate(s.getDate());
                bookings[i].setTravelDate(s.getTravelDate());
                bookings[i].setTicketType(s.getTicketType());
                bookings[i].setDestination(s.getDestination());
            }
        }

        // Write updated bookings to file
        boolean isFirst = true;
        for (Booking booking : bookings) {
            if (booking != null) {
                writeBooking(booking, !isFirst);  // Append after first write
                isFirst = false;
            }
        }
    }
}
